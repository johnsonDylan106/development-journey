<!--
   File info: prjWebForm\index.php - Initialize the array that's being used in the next page
   Created by: Dylan Johnson - johnsond47@csp.edu
   Date Written: 3/19/2023

   Version History:

-->

<!doctype html>
<html lang="en">
<head>
 <meta charset="utf-8">
 <title>Loading...</title>
<script> 
    window.onload = function() { window.location.href = "employees.php";}; //This is used to auto load the correct page.
</script>
</head>
<body>
   
<!-- In theory I would like this to be an import of data instead of hardcoded but for the purposes of this assignment I think it's what you are looking for-->
   <?php
        session_start();
        $employeeInfo = array(
        array("John", "Doe", "1234", "555-1234"),
        array("Jane", "Smith", "5678", "555-5678"),
        array("Bob", "Johnson", "9101", "555-9101")
        );
        
        $_SESSION['employeeInfo'] = $employeeInfo;
    ?>
<!--------------------------------------------------------------------------------->

</body>
</html>