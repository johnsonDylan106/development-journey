<!--
   File info: prjWebForm\index.php - host a form for new employee information
   Created by: Dylan Johnson - johnsond47@csp.edu
   Date Written: 3/19/2023

   Version History:

-->

<!doctype html>
<html lang="en">
<head>
 <meta charset="utf-8">
 <title>Employee Form</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div id="frame">

   <h1>Employee Form</h1>
   
   <?php
        //imports the array of employees from index.php----
        session_start();
        if (!isset($_SESSION['employeeInfo'])) {
            $_SESSION['employeeInfo'] = array();
        }
        
        $employeeInfo = $_SESSION['employeeInfo'];
        //--------------------------------------------------
    
        //Functions that are called below ------------------------------------------------------
        function printEmployee() {
            global $employeeInfo;
            foreach($employeeInfo as $employee) {
                echo "<p>";
                echo "Employee: ". $employee[0]. " ". $employee[1]. "<br/>";
                echo "CompanyID: ". $employee[2]. "<br/>";
                echo "Phone Number: ". $employee[3];
                echo "</p>";
            }
        }

        function addEmployee() {
            global $employeeInfo;
            $row = array();
            $row[] = $_POST['txtFName'];
            $row[] = $_POST['txtLName'];
            $row[] = $_POST['txtCompanyID'];
            $row[] = $_POST['txtPhoneNumber'];
            $employeeInfo[] = $row;
            $_SESSION['employeeInfo'] = $employeeInfo;
        }

        function selectEmployee() {
            global $employeeInfo;
            echo "<form method='POST'>";
            echo "<label>Select an employee to remove:</label>";
            echo "<select name='lstEmployee'>";
            foreach ($employeeInfo as $index => $row) {
                echo "<option value='$index'>$row[0] $row[1]</option>";
            }
            echo "</select><br/>";
            echo "<input type='submit' name='btnRemoveEmployee' value='Remove Employee'>";
            echo "</form>";
        }
        //--------------------------------------------------------------------------------------
         
  
   ?>

<!-- Main form used in this page--------------------------------------------------------------->
   <form method="POST">
      <input type="text" name="txtFName" placeholder="Employee First Name"></input><br/>
      <input type="text" name="txtLName" placeholder="Employee Last Name"></input><br/>
      <input type="text" name="txtCompanyID" placeholder="Employee ID"></input><br/>
      <input type="text" name="txtPhoneNumber" placeholder="Employee Phone Number"><br/>
      <input type="submit" name="btnAdd" value="Add Employee"></input>
    </form>
    <form method="POST">
        <input type="submit" name="btnView" value="View Employees"></input>
        <input type="submit" name="btnRemove" value="Remove Employee"></input><br/><br/>
    </form>
<!---------------------------------------------------------------------------------------------->

   <?php

        if (isset($_POST['btnAdd'])) {
            addEmployee(); //adds employee to the array
        }

        if (isset($_POST['btnView'])) {
            printEmployee(); //prints out all employees in the array
        }

        if (isset($_POST['btnRemove'])) {
            selectEmployee(); //gets the selection of which employee to remove
        }
        //Removes the selected employee above----------------
        /*I couldn't get this to work by adding it to 
         * the selectedEmployee function or in it's own
         * function. I am not sure why but this is currently
         * the only way I can get it to actually remove the 
         * employee from the array
         */
        if (isset($_POST['btnRemoveEmployee'])) {
            $index = $_POST['lstEmployee'];
            unset($employeeInfo[$index]);
            $_SESSION['employeeInfo'] = $employeeInfo;
        }
        //---------------------------------------------------


   ?>




</div>
</body>
</html>
