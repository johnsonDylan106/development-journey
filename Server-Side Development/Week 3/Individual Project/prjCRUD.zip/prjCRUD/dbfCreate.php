<!DOCTYPE html>
<html lang='en'>
   <head>
   <meta charset="utf-8" />
   <title>Student Grades Create</title>
   </head>
<body>
<h1>Create Student Grades Database</h1>
<?PHP
    /* dbfCreate.php - Demonstrate SQL create and populate
                Concordia Student Grades
    Written by Dylan Johnson
    Written:   4/2/23
    Revised:   
    */
    
    // Set up connection constants
    // Using default username and password for AMPPS  
    define("SERVER_NAME","localhost");
    define("DBF_USER_NAME", "root");
    define("DBF_PASSWORD", "mysql");
    define("DATABASE_NAME", "studentGrade");

    // Create connection object
    $conn = new mysqli(SERVER_NAME, DBF_USER_NAME, DBF_PASSWORD);

    // Start with a new database to start primary keys at 1
    $sql = "DROP DATABASE IF EXISTS " . DATABASE_NAME;
    runQuery($sql, "DROP " . DATABASE_NAME, true);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Create database if it doesn't exist
    $sql = "CREATE DATABASE IF NOT EXISTS " . DATABASE_NAME;

    runQuery($sql, "Creating " . DATABASE_NAME, false);

    // Select the database
    $conn->select_db(DATABASE_NAME);

    /*******************************
     * Create the tables
     *******************************/
    // Create Table:student
    $sql = "CREATE TABLE IF NOT EXISTS student (
        student_ID INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
        fName     VARCHAR(25) NOT NULL,
        lName     VARCHAR(25) NOT NULL,
        major_ID  INT(6)
        )";

    runQuery($sql, "Creating student ", false);

    // Create Table:class
    $sql = "CREATE TABLE IF NOT EXISTS class (
        class_ID     INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
        className    VARCHAR(25) NOT NULL,
        major_ID     INT(5)
        )";
    runQuery($sql, "Table:class", false);

    // Create Table:major
    $sql = "CREATE TABLE IF NOT EXISTS major (
        major_ID      INT(6) PRIMARY KEY, 
        majorName     VARCHAR(25) NOT NULL
        )";
    runQuery($sql, "Table:major", false);

    // Create Table:letterGrade
    $sql = "CREATE TABLE IF NOT EXISTS letterGrade (
        grade_ID      INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
        letterGrade   CHAR(1) NOT NULL
        )";
    runQuery($sql, "Table:letterGrade", false);


    // Create Table:finalGrade if it doesn't exist
    // One class can have mulitple students
    $sql = "CREATE TABLE IF NOT EXISTS finalGrade (
        student_ID INT(6) NOT NULL,
        class_ID   INT(6) NOT NULL,
        grade_ID   INT(6)
        )"; 
    runQuery($sql, "Table:runner_race", false);


    /***************************************************
     * Populate Tables Using Sample Data
     * This data will later be collected using a form.
     ***************************************************/
    // Populate Table:student

    $studentArray = array(
        array("Dylan", "Johnson", 1),
        array("James", "West", 1),
        array("Susan", "Furtney", 1),
        array("Jim", "Beam", 2),
        array("Test", "Student", 99),
        array("Johnny", "Walker", 98)
        );
    
    foreach($studentArray as $student) {   
        echo $student[0] . " " . $student[1] . "<br />";
        $sql = "INSERT INTO student (fName, lName, major_ID) "
            . "VALUES ('" . $student[0] . "', '" 
            . $student[1] . "', '" 
            . $student[2] . "')";
        
        runQuery($sql, "Record inserted for: " .$student[1], false);
    }
    //end student---------------------------------------------------------

    // Populate Table:class
    $classArray = array(
        array("Server Side Development", 1),
        array("Client Side Development", 1),
        array("Intro to Python", 1),
        array("College Writing", 2)
    );
    
    foreach($classArray as $class) {
        $sql = "INSERT INTO class (class_ID, className, major_ID) "
            . "VALUES (NULL, '" . $class[0] . "', '" 
            . $class[1] . "')";
            
        //echo "\$sql string is: " . $sql . "<br />";
        runQuery($sql, "New record insert $class[1]", false);
    }
    //end class-------------------------------------------------------

    // Populate Table:major
    $majorArray = array(
        array("Computer Science",  1),
        array("Drinking", 98)
        );
        
    foreach($majorArray as $major) {
        $sql = "INSERT INTO major (major_ID, majorName) "
            . "VALUES (" . $major[1] . ", '" . $major[0] . "')";
            
        //echo "\$sql string is: " . $sql . "<br />";
        runQuery($sql, "New record insert $major[0]", false);
    }
    //end major-----------------------------------------------------

    // Populate Table:letterGrade
    $letterGradeArray = array(
        array("A",  1),
        array("B",  2),
        array("C",  3),
        array("D",  4),
        array("F",  5)
        );
        
    foreach($letterGradeArray as $letterGrade) {
        $sql = "INSERT INTO letterGrade (grade_ID, letterGrade) "
            . "VALUES (NULL, '" . $letterGrade[0] . "')";
            
        //echo "\$sql string is: " . $sql . "<br />";
        runQuery($sql, "New record insert $letterGrade[0]", false);
    }
    //end letterGrade-----------------------------------------------
    
    // Populate Table:finalGrade\
    $sql = "SELECT student_ID FROM student ";
    $result = $conn->query($sql);
    //$studentRecord = $result->fetch_assoc();
    $studentRecord = array();
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $studentRecord[] = $row['student_ID'];
        }
    }else {
        echo "0 results";
    }

    $sql = "SELECT class_ID FROM class ";
    $result = $conn->query($sql);
    //$classRecord = $result->fetch_assoc();
    $classRecord = array();
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $classRecord[] = $row['class_ID'];
        }
    }else {
        echo "0 results";
    }

    foreach($studentRecord as $studentID) {
        foreach($classRecord as $classID) {
            $sql = "INSERT INTO finalGrade (student_ID, class_ID, grade_ID) "
                    . "VALUES ('" . $studentID . "', '" . $classID . "', NULL)";
            $result = $conn->query($sql);
        }
    }

    // Check to make sure a student isn't being added to the same class twice.

    $conn->close();



    /********************************************
     * displayResult( ) - Execute a query and display the result
     *    Parameters:  $rs - result set to display as 2D array
     *                 $sql - SQL string used to display an error msg
     ********************************************/
    function displayResult($result, $sql) {

    } // end of displayResult( )


    /********************************************
     * runQuery( ) - Execute a query and display message
     *    Parameters:  $sql         -  SQL String to be executed.
     *                 $msg         -  Text of message to display on success or error
     *     ___$msg___ successful.    Error when: __$msg_____ using SQL: ___$sql____.
     *                 $echoSuccess - boolean True=Display message on success
     ********************************************/
    function runQuery($sql, $msg, $echoSuccess) {
        global $conn;
        
        // run the query
        if ($conn->query($sql) === TRUE) {
        if($echoSuccess) {
            echo $msg . " successful.<br />";
        }
        } else {
        echo "<strong>Error when: " . $msg . "</strong> using SQL: " . $sql . "<br />" . $conn->error;
        }   

    } // end of runQuery( ) 
?>

</body>
</html>