<!DOCTYPE html>
<html lang='en'>
   <head>
   <meta charset="utf-8" />
   <title>Join Student Grades Database</title>
   <link rel="stylesheet" type="text/css" href="style.css">
   </head>
<body>

    <div class="sql">
        <h1>SQL Tables</h1>
        <?PHP
            /* 
                dbfJoin.php - Experiment with SQL JOINS
                Written by Dylan Johnson
                Written  4/2/23
                Revised: 
            */
            
            // Set up connection constants
            // Using default username and password for AMPPS  
            define("SERVER_NAME","localhost");
            define("DBF_USER_NAME", "root");
            define("DBF_PASSWORD", "mysql");
            define("DATABASE_NAME", "studentGrade");

            // Create connection object
            $conn = new mysqli(SERVER_NAME, DBF_USER_NAME, DBF_PASSWORD);
            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            } 

            // Select the database
            $conn->select_db(DATABASE_NAME);

            //Displays all table information------------
            // Display Table:student
            echo "All Fields FROM student<br />";
            $sql = "SELECT * FROM student";
            $result = $conn->query($sql);
            displayResult($result, $sql);
            echo "<br/>";

            // Display Table:class
            echo "All Fields FROM class<br/>";
            $sql = "SELECT * FROM class";
            $result = $conn->query($sql);
            displayResult($result, $sql);
            echo  "<br/>";

            // Display Table:major
            echo "All Fields FROM major<br/>";
            $sql = "SELECT * FROM major";
            $result = $conn->query($sql);
            displayResult($result, $sql);
            echo  "<br/>";

            // Display Table:letterGrade
            echo "All Fields FROM letterGrade<br/>";
            $sql = "SELECT * FROM letterGrade";
            $result = $conn->query($sql);
            displayResult($result, $sql);
            echo  "<br/>";

            // Display Table:finalGrade
            echo "All Fields FROM finalGrade<br/>";
            echo "The intent here is that an interface would
                allow the teacher to input data.<br/>";
            $sql = "SELECT * FROM finalGrade";
            $result = $conn->query($sql);
            displayResult($result, $sql);
            echo  "<br/>";

            //end all datable information------------


            //Begin JOIN statements--------------------------------------------------------------------------------

            // LEFT OUTER JOIN
            echo "LEFT OUTER JOIN (Left table: class)<br />";
            $sql = "SELECT s.fName, c.className, m.majorName as 'Class Major' FROM finalGrade fg
                    LEFT JOIN class c
                    ON c.class_ID = fg.class_ID
                    LEFT JOIN student s 
                    ON s.student_ID = fg.student_ID 
                    LEFT JOIN major m 
                    ON m.major_ID = c.major_ID";
            $result = $conn->query($sql);
            displayResult($result, $sql);
            echo "<br />";

            // RIGHT OUTER JOIN
            echo "RIGHT OUTER JOIN (Right table: sponsor)<br />";
            $sql = "SELECT CONCAT(s.fName, ' ', s.lName) AS Name, m.majorName FROM major m 
                    RIGHT OUTER JOIN student s 
                    ON s.major_ID = m.major_ID 
                    ORDER BY s.student_ID";
            $result = $conn->query($sql);
            displayResult($result, $sql);
            echo "<br />";
            //end JOIN statements---------------------------------------------------------------------------------


            // Close the database
            $conn->close();


            /********************************************
             * displayResult( ) - Execute a query and display the result
             * Parameters: $rs  - Result set to display as 2D array
             *             $sql - SQL string used to display an error msg
             ********************************************/
            function displayResult($result, $sql) {
                if ($result->num_rows > 0) {
                    echo "<table border='1'>\n";
                    // print headings (field names)
                    $heading = $result->fetch_assoc( );
                    echo "<tr>\n";
                    // print field names 
                    foreach($heading as $key=>$value){
                    echo "<th>" . $key . "</th>\n";
                    }
                    echo "</tr>\n";
                    
                    // Print values for the first row
                    echo "<tr>\n";
                    foreach($heading as $key=>$value){
                    echo "<td>" . $value . "</td>\n";
                    }
                            
                    // output rest of the records
                    while($row = $result->fetch_assoc()) {
                        //print_r($row);
                        //echo "<br />";
                        echo "<tr>\n";
                        // print data
                        foreach($row as $key=>$value) {
                            echo "<td>" . $value . "</td>\n";
                        }
                        echo "</tr>\n";
                    }
                    echo "</table>\n";
                // No results
                } else {
                    echo "<strong>zero results using SQL: </strong>" . $sql;
                }   
            } // end of displayResult( )

            /********************************************
             * runQuery( ) - Execute a query and display message
             *    Parameters:  $sql         -  SQL String to be executed.
             *                 $msg         -  Text of message to display on success or error
             *     ___$msg___ successful.    Error when: __$msg_____ using SQL: ___$sql____.
             *                 $echoSuccess - boolean True=Display message on success
             ********************************************/
            function runQuery($sql, $msg, $echoSuccess) {
            global $conn;
                
            // run the query
            if ($conn->query($sql) === TRUE) {
                if($echoSuccess) {
                    echo $msg . " successful.<br />";
                }
            } else {
                echo "<strong>Error when: " . $msg . "</strong> using SQL: " . $sql . "<br />" . $conn->error;
            }   
            } // end of runQuery( ) 
        ?>
    </div>

    <div class="text">
        <p>I might have misinterpreted the assignment at first. However I think in a way I still incorporated it all.</p>
        <p>I added 5 tables instead of 3 because as I was building it out I had all the normal forms in my head.</p>
        <p>So to explain the different joins. A left outer join returns all results from the first "FROM" statement and pairs that information off with the table(s) on the right.</p>
        <p>Wheras a right outer join returns info from the right most tables, using the left table information.</p>
        <p>In either case, if no result it will return NULL.</p>
    </div>

</body>
</html>