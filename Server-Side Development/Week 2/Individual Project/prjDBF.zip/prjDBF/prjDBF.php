<!-- 
    prjDBF.html - Demonstrate using SELECT to display data
    Dylan Johnson
    Written:   3/27/23
    Revised:   3/27/23
-->


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>myStore</title>

    <link rel="stylesheet" type="text/css" href="style.css">

    <?PHP

        // Credentials for localhost server
        define('DBF_NAME', 'mystoreweek02');
        define('DBF_USER', 'root');
        define('DBF_PASSWORD', 'mysql');
        /*
        // Credentials for remote 
        serverdefine('DATABASE_NAME', 'mystoreweek02');
        define('DBF_USER', 'root');
        define('DBF_PASSWORD', 'mysql');
        */

        // Set up constants for each table format
        define('PRODUCT', '0');
        define('MANAGER', '1');
        define('MANUFACTURER', '2');
        $tableFormat = null;
        $sql = 'SELECT * FROM product';

        // Is this a return visit?
        if(array_key_exists('hidIsReturning',$_POST)) {
            echo '<h1>Welcome back to myStore!</h1>';
            //print_r($_POST);

            echo '<br />';

            // display the list of music works based on the selection
            if(isset($_POST['lstDisplay'])) {
                // Save item that was selected by the user
                $selection = $_POST['lstDisplay'];
                //echo 'DEBUG $selection: ' . $selection . '<br />';
                switch($selection) {
                    case "product": {
                        $tableFormat=PRODUCT;
                        $sql = "SELECT 
                                    product.productName,
                                    product.productPrice, 
                                    product.productOnHand,
                                    product.productPage,
                                    color.color,
                                    department.departmentName
                                FROM product
                                JOIN color
                                ON product.color_Id = color.color_Id
                                JOIN department
                                ON product.department_Id = department.department_Id";
                        break;
                    }
                    case "manager": {
                        $tableFormat=MANAGER;
                        $sql = "SELECT 
                                    manager.fName,
                                    manager.lName,
                                    department.departmentName
                                FROM manager
                                JOIN department
                                ON department.manager_Id = manager.manager_Id";
                        break;
                    }

                    case "manufacturer": {
                        $tableFormat=MANUFACTURER;
                        $sql = "SELECT 
                                   manufacturerName,
                                   manufacturerSite
                                FROM manufacturer";
                        break;
                    }

                    default: echo $selection . 
                        ' is not a valid choice from the list of displays<br />';
                }// end of switch( )
            } // if(isset( ))

        }
        else // or, a first time visitor?
        {
            echo '<h1>Welcome to myStore</h1>';
        } // end of if new else returning

        function displayData( ) {
            global $sql;
            global $tableFormat;
            //echo 'DEBUG: $sql: ' . $sql . '<br />';
            // Create a database object
            // PARAMETERS:   server       user    password database
            $db = new mysqli('localhost', DBF_USER, DBF_PASSWORD, DBF_NAME);
          
            if($db->connect_errno > 0){
             die('Unable to connect to database [' . $db->connect_error . ']');
            }
            
            // Get the data from the database using SQL
            if(!$result = $db->query($sql)){
             die('There was an error running the query [' . $db->error . ']');
            }
            
            // Display the records in a table
            // while($row = $result->fetch_assoc()){
            // echo $row['title'] . '<br />';
            // }
            switch($tableFormat) {
                case PRODUCT:
                {
                    echo '<h2>Products</h2>';
                    echo '<table>';
                    echo "<tr> <th>Product Name</th> 
                           <th>Price</th> 
                           <th># Available</th> 
                           <th>Color</th> 
                           <th>Department</th> 
                           <th>URL</th> </tr>";

                           while($row = $result->fetch_assoc()) {
                            echo "<tr> <td>".$row["productName"]."</td> 
                                       <td>".$row["productPrice"]."</td> 
                                       <td>".$row["productOnHand"]."</td> 
                                       <td>".$row["color"]."</td>
                                       <td>".$row["departmentName"]."</td> 
                                       <td>".$row["productPage"]."</td> </tr>";
                        }
                    echo '</table>';
                    break;
                }

                case MANAGER:
                {
                    echo '<h2>Managers</h2>';
                    echo '<table>';
                    echo "<tr> <th>First Name</th> 
                    <th>Last Name</th>
                    <th>Department</th> </tr>";
                
                    while($row = $result->fetch_assoc()) {
                        echo "<tr> <td>".$row["fName"]."</td> 
                                   <td>".$row["lName"]."</td>
                                   <td>".$row["departmentName"]."</td> </tr>";
                    }
                    echo '</table>';
                    break;
                }

                case MANUFACTURER:
                    {
                        echo '<h2>Manufacturers</h2>';
                        echo '<table>';
                        echo "<tr> <th>Name</th> 
                                   <th>URL</th> </tr>";
                    
                        while($row = $result->fetch_assoc()) {
                            echo "<tr> <td>".$row["manufacturerName"]."</td> 
                                       <td>".$row["manufacturerSite"]."</td> </tr>";
                        }
                        echo '</table>';
                        break;
                    }

                case null:
                    {
                        break;
                    }

                default:
                echo $tableFormat . ' is not a valid table format.<br />';
            } // end of switch( )
            
            if(!($tableFormat == null)) {
                echo '<br />Total results: ' . $result->num_rows;
            }
    
            // Close the database object
            $db->close();
        } // end of displayData( )


    ?>

</head>
    <body>
        <div id="frame">

            <form name="frmDBF"
                        action='<?php echo htmlentities($_SERVER['PHP_SELF']); ?>'
                        method="POST">
                    <strong>What information would you like to view?</strong>
                    <!-- Use JavaScript to automatically submit the selection -->
                    <select name="lstDisplay" onchange="this.form.submit()">
                        <option value="null">Select an item</option>
                        <option value="product">Products</option>
                        <option value="manager">Managers</option>
                        <option value="manufacturer">Manufacturers</option>
                    </select>

                    <!-- set up alternative button in case JavaScript is not active -->
                    <noscript>
                        &nbsp; &nbsp; &nbsp;
                        <input type="submit" name="btnSubmit" value="View the list" />
                        <br /><br />
                    </noscript>

                    <!-- Use a hidden field to tell server if return visitor -->
                    <input type="hidden" name="hidIsReturning" value="true" />
                </form>

                <?PHP
                    displayData( );
                ?>

        </div>
        
        <p>The first steps I took when creating this page was setting up the database. I had to expand the data that 
            as given into 1NF and that gave me 5 different tables. Once I had that in a good spot, I created the database in 
            PHPMyAdmin and than uploaded the data to the database. I was than able to use the lab sample as a template to build the rest
            of the website that you see above. <br><br>To see the database design <a href="graphic/database.png">click here</a>.</p>

    </body>
</html>