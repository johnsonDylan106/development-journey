<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>JSONEdit</title>
        <?php

            session_start();
            $json_file = file_get_contents("priceData.json");
            $json_data = json_decode($json_file, true);
            
            //Creates the table to edit the contents of the json file
            //This is ONLY practicle because of so little data being worked with
            //With more time I would've added a dropdown to select the "part" the user wanted to change and populated accordingly
            echo '<form method="post">';
            foreach($json_data['parts'] as $key => $part) {
                echo '<label for="name[' . $key . ']">Name:</label>';
                echo '<input type="text" id="name[' . $key . ']" name="name[' . $key . ']" value="' . $part['name'] . '"></br>';

                echo '<label for="price[' . $key . ']">Price:</label>';
                echo '<input type="text" id="price[' . $key . ']" name="price[' . $key . ']" value="' . $part['price'] . '"></br>';

                echo '<label for="sku[' . $key . ']">SKU:</label>';
                echo '<input type="text" id="sku[' . $key . ']" name="sku[' . $key . ']" value="' . $part['sku'] . '"></br>';
                
                echo '<label for="description[' . $key . ']">Description:</label></br>';
                echo '<textarea id="description[' . $key . ']" name="description[' . $key . ']">' . $part['description'] . '</textarea></br></br>';
            }
            echo '<input type="submit" name="submit" value="Save Changes">';
            echo '</form>';
            echo '<pre>'. json_encode($json_data, JSON_PRETTY_PRINT) . '</pre>';
            //end form

            //When the above form is submited, the contents are saved
            //Again, this is the solution because of so little data.
            if(isset($_POST['submit'])) {
                // loop through each product in the JSON data
                foreach($json_data['parts'] as $key => $product) {
                    // update the product information with the form data
                    $json_data['parts'][$key]['name'] = $_POST['name'][$key];
                    $json_data['parts'][$key]['price'] = $_POST['price'][$key];
                    $json_data['parts'][$key]['description'] = $_POST['description'][$key];
                    $json_data['parts'][$key]['sku'] = $_POST['sku'][$key];
                }
                
                // save the updated JSON data in a session variable
                $_SESSION['json_data'] = urlencode(serialize($json_data));
                
                // write the updated JSON data to the file
                file_put_contents("priceData.json", json_encode($json_data));
            }
            //End update of json file

            // check if there is updated JSON data in the session
            if(isset($_SESSION['json_data'])) {
                // decode the serialized JSON data and decode the URL encoding
                $json_data = json_decode(urldecode($_SESSION['json_data']), true);
            }

        ?>


    </head>
    <body>
            <ul>
                <li>What is AJAX? What does it do? What are its advantages?
                    <ul>
                        <li>AJAX stands for Asynchronus JavaScript and XML</li>
                        <li>This is a way for webpages to update without the need to refresh the page or make any new calls to databases</li>
                        <li>A couple benifits would be
                            <ul>
                                <li>Fast response time imporving UX</li>
                                <li>As mentioned above, no server calls which in turn reduces data movement from server to client.</li>
                                <li>For a third, IJ'd say it's verstaility in it's ability to work across JSON, XML, and HMTL</li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li>How can PHP be used to create JSON data from database instead of the static .json file?
                    <ul>
                        <li>Essentially PHP can pull data from a database and then format that information on a page as if it were a JSON file.</li>
                        <li>This allows for a single call for data in a seperate page that can be pulled in for ease of access</li>
                    </ul>
                </li>
                <li>Based on the learning activities, write an algorithm and develop a flow chart showing the steps involved using a JSON Server getting data from a DBF and responding with JSON data to a web page using AJAX.
                    <ul>
                        <li>A few basic steps to this would be:
                            <ul>
                                <li>Figure out the data you need from the DB and create the SQL query</li>
                                <li>Develop the PHP page that will connect to the DB and run that SQL query</li>
                                <li>Format the output of the query into a table that replicates the JSON format</li>
                                <li>Finally, make the content-type of the page "application/json"
                                    <ul>
                                        <li>This will allow for other pages to call the PHP page from anywhere on the web as if it were a JSON file</li>
                                        <li>This is the essense of an API</li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
            </ul>
    </body>
</html>