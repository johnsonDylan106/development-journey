<?PHP 
    /* employeeLibrary.php - For week 4 individual project
    Written by Dylan Johnson
    Written:   4/10/23
    Revised:   
    */
    function createConnection( ) {
        global $conn;
        define("SERVER_NAME","localhost");
        define("DBF_USER_NAME", "root");
        define("DBF_PASSWORD", "mysql");
        define("DATABASE_NAME", "workSchedule");
        // Create connection object
        $conn = new mysqli(SERVER_NAME, DBF_USER_NAME, DBF_PASSWORD);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
        // Select the database
        $conn->select_db(DATABASE_NAME);
    } // end of createConnection( )

    function displayMessage($msg, $color) {
        echo "<hr /><strong style='color:" . $color . ";'>" . $msg . "</strong><hr />";
    }

    function defaultEmployee() {
        $employeeInfo = [
            "employee_ID" => 0,
            "day_ID" => 0,
            "shift_ID" => 0,
            "Name" => "Name",
            "workDay" => "Work Day",
            "workShift" => "Work Shift"
        ];
        return $employeeInfo;
    }
    
    function displayResult($result, $sql) {
        if ($result->num_rows > 0) {
        echo "<table border='1'>\n";
        // print headings (field names)
        $heading = $result->fetch_assoc( );
        echo "<tr>\n";
        // print field names 
        foreach($heading as $key=>$value){
            echo "<th>" . $key . "</th>\n";
        }
        echo "</tr>\n";
        
        // Print values for the first row
        echo "<tr>\n";
        foreach($heading as $key=>$value){
            echo "<td>" . $value . "</td>\n";
        }
                    
            // output rest of the records
            while($row = $result->fetch_assoc()) {
                //print_r($row);
                //echo "<br />";
                echo "<tr>\n";
                // print data
                foreach($row as $key=>$value) {
                echo "<td>" . $value . "</td>\n";
                }
                echo "</tr>\n";
            }
            echo "</table>\n";
        } else {
            echo "<strong>zero results using SQL: </strong>" . $sql;
        }
    } // end of displayResult( )

    function displaySchedule() {
        global $conn;
        $sql = "SELECT CONCAT(employee.FNAME, ' ', employee.lName) AS 'Employee Name', 
                    dayofweek.dayOfWeek as 'Work Day', workshift.shiftName as 'Work Shift', 
                    DATE_FORMAT(shifttime.shiftTimeStart, '%l:%i %p') as 'Start Time', 
                    DATE_FORMAT(shifttime.shiftTimeEnd, '%l:%i %p') as 'End Time'
                    FROM `schedule` 
                    JOIN EMPLOYEE ON employee.employee_ID = schedule.employee_ID 
                    JOIN dayofweek ON dayofweek.day_ID = schedule.day_ID
                    JOIN workshift ON workshift.shift_ID = schedule.shift_ID
                    JOIN shifttime ON workshift.shiftTime_ID = shifttime.shiftTime_ID
                    ORDER BY dayofweek.day_ID";
        $result = $conn->query($sql);
        displayResult($result, $sql);
    }

    function shiftView($emp, $dayOfWeek) {
        global $conn;
        $sql = "SELECT schedule.employee_ID, schedule.day_ID, schedule.shift_ID, 
		CONCAT(employee.FNAME, ' ', employee.lName) AS 'Name', 
        dayofweek.dayOfWeek AS 'workDay', workshift.shiftName as 'workShift'
        FROM `schedule` 
        JOIN EMPLOYEE ON employee.employee_ID = schedule.employee_ID 
        JOIN dayofweek ON dayofweek.day_ID = schedule.day_ID
        JOIN workshift ON workshift.shift_ID = schedule.shift_ID
        WHERE schedule.employee_ID =" . $emp
        . " AND schedule.day_ID = " . $dayOfWeek;

        $result = $conn->query($sql);
        
        if ($result->num_rows == 0 || $result == NULL) {
            return NULL;
        }

        return $result;
    }

?>