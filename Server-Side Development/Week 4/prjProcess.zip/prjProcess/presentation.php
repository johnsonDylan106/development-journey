<!-- 
    presentation.php - For week 4 individual project
    Written by Dylan Johnson
    Written:   4/10/23
    Revised: 
-->
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="style1.css">
        <title>Presentation</title>
    </head>

    <body>
        <div id="headers">
            <h1>Employee PTO and Sick time application</h1>
            <h2>Dylan Johnson</h2>
            <h2 id="date">4/10/23</h2>
        </div>

        <div class="links">
            <a href="index.php">Schedule</a>
            <a href="edit.php">Admin Page</a>
        </div>
        <div id="image">
            <a href="graphic/userPage.png">User Page WireFrame</a>
            <a href="graphic/adminPage.png">Admin Page WireFrame</a>
        </div>

        <table id="qa">
            <thead>
                <tr>
                    <td class="first">Questions</td>
                    <td>Answers</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="left">
                        <ol class="question">
                            <li>Who will be using the site?</li>
                            <li>Who will just be viewing the site?</li>
                            <li>Who will be adding/editing information?</li>
                            <li>What type of information do you expect users to see?</li>
                            <li>What do you want admins to be able to do?</li>
                            <li>When would you expect to have this available for use?</li>
                            <li>What features would you like available at the launch?</li>
                            <li>Where would you like users to be able to access the app?</li>
                            <li>Why are you wanting this built?</li>
                            <li>What software are you already using?</li>
                        </ol>
                    </td>
                    <td class="right">
                        <ol class="answer">
                            <li>This site is to be used by all employees at the company. Talking 100+</li>
                            <li>Everyone should be able to view, but only their own information.</li>
                            <li>I would expect employees to be able to submit requests, but managers are the only ones able to modify.</li>
                            <li>The users should be able to see what has been used as well as remaining balances.</li>
                            <li>Admins should be able to approve requests submitted by users as well as update balances.</li>
                            <li>I want this available ASAP</li>
                            <li>Bare minimum at launch I want viewable PTO balances and PTO that is on the books.</li>
                            <li>For ease of access, I want my employees to be able to access this anywhere. Not just on network.</li>
                            <li>There have been a lot of complaints with the current HR software and I want something that will be more user friendly.</li>
                            <li>As far as HR goes, we are using product xyz. Outside of that we primarily work with the Microsoft suite.</li>
                        </ol>
                    </td>
                </tr>
            </tbody>

            <tfoot>
                <tr>
                    <td colspan="2">**Answers from client directly.**</td>
                </tr>
                <tr>
                    <td colspan="2">I changed the project at the end so this Q/A and PA below might not make as much sense.</td>
                </tr>
            </tfoot>
        </table>

        <div class="problemAnalysis">
            <h1>Problem Analysis</h1>
            <p>There are several different ways this problem could be solved. Honestly, it comes down to how "fancy" you want the solution to be; as well as how much money you are willing to throw at it.
                I am bringing 2 solutions to the table for you to pick from based on the answers to my questions. First, since you are already using the Microsoft Suite, a template could be built out in a SharePoint
                site. This would provide easy integration into tools already being used by your team, while keeping costs down. The second solution is a built from scratch tool. This would allow you to have full control of design, integration
                and information storage/shared. This will cost a bit more but ultimately depends on what you are looking for. Are you wanting the, so to speak, Apple product that has been built for you and you mold to it. Or do you want
                the, so to speak, Android product where you are in complete control?

            </p>

        </div>

    </body>

</html>
