<!-- 
    index.php - For week 4 individual project
    Written by Dylan Johnson
    Written:   4/10/23
    Revised: 
-->

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Employee Schedule</title>
        <link rel="stylesheet" href="style1.css">
        <?PHP 
            include_once("./employeeLibrary.php");
            createConnection();
        ?>
    </head>
    <body>
        <div id="header">
            <h1>Employee Schedules:</h1>
        </div>
        <div id="table">
            <?PHP 
                displaySchedule();
            ?>
        </div>
    </body>
</html>