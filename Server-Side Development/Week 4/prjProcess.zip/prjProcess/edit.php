<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin Page</title>
        <link rel="stylesheet" href="style1.css">
        <?PHP 
            include_once("./employeeLibrary.php");
            createConnection();
            if($_SERVER['REQUEST_METHOD'] === 'POST') {
                switch($_POST['btnSubmit']) {
                    case 'search': 
                        if ($_POST['employee'] == 0) {
                            displayMessage("No Employee Selected", "Red");
                            $employeeInfo = defaultEmployee();
                        } else {
                            $result = shiftView($_POST['employee'], $_POST['workDay']);
                            if ($result == NULL) {
                                displayMessage("Not Currently Scheduled", "Red");
                                $employeeInfo = defaultEmployee();
                            }else {
                                $row = $result->fetch_assoc();
                                $employeeInfo = [
                                    "employee_ID" => $row['employee_ID'],
                                    "day_ID" => $row['day_ID'],
                                    "shift_ID" => $row['shift_ID'],
                                    "Name" => $row['Name'],
                                    "workDay" => $row['workDay'],
                                    "workShift" => $row['workShift']
                                ];
                            }
                        }
                        break;

                    case 'update':
                        if ($_POST['employee'] == 0) {
                            displayMessage("No schedule to change", "Red");
                            $employeeInfo = defaultEmployee();
                        } else if ($_POST['workShift'] == 4) {
                            $sql = "DELETE FROM schedule WHERE employee_ID = " . 
                            $_POST['employee'] . " AND day_ID = " . $_POST['workDay'];
                            $conn->query($sql);
                            displayMessage("The Shift has been removed", "Red");
                            $employeeInfo = defaultEmployee();
                        } else {
                            $sql = "INSERT INTO schedule (employee_ID, day_ID, shift_ID) 
                                    VALUES (" . $_POST['employee'] . ", " . $_POST['workDay']
                                    . ", " . $_POST['workShift'] . ") ON DUPLICATE KEY UPDATE 
                                    shift_ID=" . $_POST['workShift'];
                            $conn->query($sql);
                            displayMessage("The schedule has been updated!", "Green");
                            $employeeInfo = defaultEmployee();
                        }
                        break;

                    default:
                        $employeeInfo = defaultEmployee();
                }
            } else {
                $employeeInfo = defaultEmployee();
            }
        ?>
    </head>
    <body>
        <div id="header">
            <h1>Schedule Admin Page</h1>
        </div>
        <form action="<?PHP echo htmlentities($_SERVER['PHP_SELF']); ?>" method="POST">
            
            <fieldset>
                <div id="empName">
                    <label for="txtName">Employee Name: </label>
                    <select name="employee" id="employee">
                        <option value="<?PHP echo $employeeInfo['employee_ID']; ?>" selected><?PHP echo $employeeInfo['Name']; ?></option>
                        <?php
                            $sql = "SELECT employee_ID, CONCAT(FNAME, ' ', LNAME) AS 'Name' FROM employee";
                            $result = $conn->query($sql);
                            while($row = $result-> fetch_assoc()) {
                                echo "<option value='" . $row['employee_ID'] . "'>" . $row['Name'] . "</option>\n";
                            }
                        ?>

                    </select>
                </div>
                
                <div id="empWorkDay">
                    <label for="txtWorkDay">Work Day: </label>
                    <select name="workDay" id="workDay">
                        <option value="<?PHP echo $employeeInfo['day_ID']; ?>" selected><?PHP echo $employeeInfo['workDay']; ?></option>
                        <?php
                            $sql = "SELECT day_ID, dayOfWeek FROM dayOfWeek";
                            $result = $conn->query($sql);
                            while($row = $result-> fetch_assoc()) {
                                echo "<option value='" . $row['day_ID'] . "'>" . $row['dayOfWeek'] . "</option>\n";
                            }
                        ?>

                    </select>
                </div>
               
                
                <div id="empWorkShift">
                    <label for="txtWorkShift">Work Shift: </label>
                    <select name="workShift" id="workShift">
                        <option value="<?PHP echo $employeeInfo['shift_ID']; ?>" selected><?PHP echo $employeeInfo['workShift']; ?></option>
                        <?php
                            $sql = "SELECT shift_ID, shiftName FROM workShift";
                            $result = $conn->query($sql);
                            while($row = $result-> fetch_assoc()) {
                                echo "<option value='" . $row['shift_ID'] . "'>" . $row['shiftName'] . "</option>\n";
                            }
                        ?>

                    </select>
                </div>
                <div id="button">
                    <button id="search" name="btnSubmit" value="search" onclick="this.form.submit();">Search</button>
                    <button id="update" name="btnSubmit" value="update" onclick="this.form.submit();">Update</button>
                </div>
            </fieldset>

        </form>
        <div id="table">
            <?php 
                displaySchedule();
            ?>
        </div>

    </body>
</html>