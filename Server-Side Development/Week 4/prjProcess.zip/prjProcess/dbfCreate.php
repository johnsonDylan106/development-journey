<!DOCTYPE html>
<html lang='en'>
   <head>
   <meta charset="utf-8" />
   <title>Schedule DB Create</title>
   </head>
<body>
<h1>Create workSchedule Database</h1>
<?PHP
    /* dbfCreate.php - For week 4 individual project
    Written by Dylan Johnson
    Written:   4/10/23
    Revised:   
    */
    
    // Set up connection constants
    // Using default username and password for AMPPS  
    define("SERVER_NAME","localhost");
    define("DBF_USER_NAME", "root");
    define("DBF_PASSWORD", "mysql");
    define("DATABASE_NAME", "workSchedule");

    // Create connection object
    $conn = new mysqli(SERVER_NAME, DBF_USER_NAME, DBF_PASSWORD);

    // Start with a new database to start primary keys at 1
    $sql = "DROP DATABASE IF EXISTS " . DATABASE_NAME;
    runQuery($sql, "DROP " . DATABASE_NAME, true);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Create database if it doesn't exist
    $sql = "CREATE DATABASE IF NOT EXISTS " . DATABASE_NAME;

    runQuery($sql, "Creating " . DATABASE_NAME, false);

    // Select the database
    $conn->select_db(DATABASE_NAME);

    /*******************************
     * Create the tables
     *******************************/
    // Create Table:employee
    $sql = "CREATE TABLE IF NOT EXISTS employee (
        employee_ID INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
        fName     VARCHAR(25) NOT NULL,
        lName     VARCHAR(25) NOT NULL
        )";

    runQuery($sql, "Creating table: employee ", false);

    // Create Table:dayOfWeek
    $sql = "CREATE TABLE IF NOT EXISTS dayOfWeek (
        day_ID          INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
        dayOfWeek       VARCHAR(10) NOT NULL,
        dayAbbreviation VARCHAR(5) NOT NULL
        )";
    runQuery($sql, "Creating table: dayOfWeek", false);

    // Create Table:workShift
    $sql = "CREATE TABLE IF NOT EXISTS workShift (
        shift_ID      INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
        shiftName     VARCHAR(15) NOT NULL,
        shiftTime_ID     INT(6) NOT NULL
        )";
    runQuery($sql, "Creating table: workShift", false);

    // Create Table:shiftTime
    $sql = "CREATE TABLE IF NOT EXISTS shiftTime (
        shiftTime_ID      INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
        shiftTimeStart    TIME NOT NULL,
        shiftTimeEnd    TIME NOT NULL,
        shift_ID          INT(6) NOT NULL
        )";
    runQuery($sql, "Creating Table: shiftTime", false);


    // Create Table:schedule if it doesn't exist
    $sql = "CREATE TABLE IF NOT EXISTS schedule (
        employee_ID    INT(6) NOT NULL,
        day_ID         INT(6) NOT NULL,
        PRIMARY KEY (employee_ID, day_ID),
        shift_ID       INT(6) NOT NULL
        )"; 
    runQuery($sql, "Table:runner_race", false);


    /***************************************************
     * Populate Tables Using Sample Data
     * This data will later be collected using a form.
     ***************************************************/
    // Populate Table:employee

    $employeeArray = array(
        array("Dylan", "Johnson"),
        array("James", "West"),
        array("Susan", "Furtney"),
        array("Test", "Employee")
        );
    
    foreach($employeeArray as $employee) {   
        echo $employee[0] . " " . $employee[1] . "<br />";
        $sql = "INSERT INTO employee (fName, lName) "
            . "VALUES ('" . $employee[0] . "', '" 
            . $employee[1] . "')";
        
        runQuery($sql, "Record inserted for: " .$employee[1], false);
    }
    //end student---------------------------------------------------------

    // Populate Table:dayOfWeek
    $dayArray = array(
        array("Monday", "Mon"),
        array("Tuesday", "Tue"),
        array("Wednesday", "Wed"),
        array("Thursday", "Thurs"),
        array("Friday", "Fri"),
        array("Saturday", "Sat"),
        array("Sunday", "Sun")
    );
    
    foreach($dayArray as $day) {
        $sql = "INSERT INTO dayOfWeek (dayOfWeek, dayAbbreviation) "
            . "VALUES ('" . $day[0] . "', '" 
            . $day[1] . "')";
            
        //echo "\$sql string is: " . $sql . "<br />";
        runQuery($sql, "New record insert $day[1]", false);
    }
    //end dayOfWeek-------------------------------------------------------

    // Populate Table:workShift
    $workShiftArray = array(
        array("First",  1),
        array("Second", 2),
        array("Third", 3),
        array("Clear Shift", 4)
        );
        
    foreach($workShiftArray as $shift) {
        $sql = "INSERT INTO workShift (shiftName, shiftTime_ID) "
            . "VALUES ('" . $shift[0] . "', '" . $shift[1] . "')";
            
        //echo "\$sql string is: " . $sql . "<br />";
        runQuery($sql, "New record insert $shift[0]", false);
    }
    //end workShift-----------------------------------------------------

    // Populate Table:shiftTime
    $shiftTimeArray = array(
        array("6:00:00", "14:00:00"  , 1),
        array("14:00:00", "22:00:00"  , 2),
        array("22:00:00", "6:00:00"  , 3)
        );
        
    foreach($shiftTimeArray as $time) {
        $sql = "INSERT INTO shiftTime (shiftTimeStart, shiftTimeEnd, shift_ID) "
            . "VALUES ('" . $time[0] . "', '" . $time[1] . "', " . $time[2] . ")";
            
        //echo "\$sql string is: " . $sql . "<br />";
        runQuery($sql, "New record insert for shift $time[2]", false);
    }
    //end shiftTime-----------------------------------------------
    
    // Populate Table:schedule
    $scheduleArray = array(
        array(1, 1, 1),
        array(1, 2, 3),
        array(1, 3, 2),
        array(2, 3, 2),
        array(2, 4, 3),
        array(2, 5, 1),
        array(3, 5, 3),
        array(3, 6, 1),
        array(3, 7, 2),
        array(4, 7, 1),
        array(4, 1, 2),
        array(4, 2, 3)
    );

    foreach($scheduleArray as $schedule) {
        $sql = "INSERT INTO schedule (employee_ID, day_ID, shift_ID) "
        . "VALUES (" . $schedule[0] . ", " . $schedule[1] . ", " 
        . $schedule[2] . ")";

        runQuery($sql, "New schedule set for employee $schedule[0]", false);
    }

    // Check to make sure a student isn't being added to the same class twice.

    $conn->close();



    /********************************************
     * displayResult( ) - Execute a query and display the result
     *    Parameters:  $rs - result set to display as 2D array
     *                 $sql - SQL string used to display an error msg
     ********************************************/
    function displayResult($result, $sql) {

    } // end of displayResult( )


    /********************************************
     * runQuery( ) - Execute a query and display message
     *    Parameters:  $sql         -  SQL String to be executed.
     *                 $msg         -  Text of message to display on success or error
     *     ___$msg___ successful.    Error when: __$msg_____ using SQL: ___$sql____.
     *                 $echoSuccess - boolean True=Display message on success
     ********************************************/
    function runQuery($sql, $msg, $echoSuccess) {
        global $conn;
        
        // run the query
        if ($conn->query($sql) === TRUE) {
        if($echoSuccess) {
            echo $msg . " successful.<br />";
        }
        } else {
        echo "<strong>Error when: " . $msg . "</strong> using SQL: " . $sql . "<br />" . $conn->error;
        }   

    } // end of runQuery( ) 
?>

</body>
</html>