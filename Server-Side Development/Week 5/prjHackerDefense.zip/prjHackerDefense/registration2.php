<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="utf-8">
<!-- registrationPrepared.php - Register new racers - edit, delete using prepared statements
  Prepared by:  Student Name
  Written:   Current Date 
  Revised:   
  -->
 <title>SunRun Registration</title>
<link rel="stylesheet" type="text/css" href="registration.css">

<?PHP
   // Set up connection constants
   // Using default username and password for AMPPS  
   define("SERVER_NAME","localhost");
   define("DBF_USER_NAME", "root");
   define("DBF_PASSWORD", "mysql");
   define("DATABASE_NAME", "sunRun");
   // Global connection object
   $conn = NULL;

   // Link to external library file
   //echo "PATH:" . getcwd( ) . "sunRunLib.php" . "<br />";
   // Need the / because getcwd( ) does not add it at the end of the path
   require_once(getcwd( ) . "/sunRunLib.php");   
   // Connect to database
   createConnection();
// Is this a return visit?
if(array_key_exists('hidIsReturning',$_POST)) {
    // Get the array that was stored as a session variable
    // Used to populate the HTML textboxes using JavaScript DOM
    $thisRunner = unserialize(urldecode($_SESSION['sessionThisRunner']));

    // Did the user select a runner from the list?
    // 'new' is the value of the first item on the runner listbox 
    if(isset($_POST['lstRunner']) && !($_POST['lstRunner'] == 'new')){
       /*Original unsafe SQL - extracting runner and sponsor info
        // Extract runner and sponsor information
       $sql = "SELECT runner.id_runner, fName, lName, phone, gender, sponsorName 
       FROM runner 
       LEFT OUTER JOIN sponsor ON runner.id_runner = sponsor.id_runner 
       WHERE runner.id_runner =" . $_POST['lstRunner'];
       $result = $conn->query($sql);
       $row = $result->fetch_assoc();
       */
      $idRunner = $_POST['lstRunner'];
      $sql = "SELECT runner.id_runner, runner.fName, runner.lName, runner.phone, runner.gender, sponsor.sponsorName 
                FROM Runner 
                LEFT outer join sponsor on runner.id_runner = sponsor.id_runner WHERE runner.id_runner=?";
      //Set up a prepared statement
      if($stmt = $conn->prepare($sql)) {
        //pass the parameters
        $stmt->bind_param("i", $idRunner);
        if($stmt->errno) {
            displayMessage("stmt prepare ( ) had error.", "red");
        }
        //Execute the query
        $stmt->execute();
        if($stmt->errno) {
            displayMessage("Could not execute prepared statement", "red");
        }
        //Optional - Download all the ros into a cache
        //When fetch() is called all the records wil be downloaded
        $stmt->store_result();
        //get number of rows
        //(only good if store_result() is used first)
        $rowCount = $stmt->num_rows;
        //Bind results to variables
        //one variable for each field in the select statement
        //this is the variable that fetch() will use to store the result
        $stmt->bind_result($idRunner, $fName, $lName, $phone, $gender, $sponsor);
        //Fetch the value - returns the next row in the result set
        while($stmt->fetch()) {
            //output the result
            echo("The id is: "     . $idRunner . "<br />");
            echo("The fName is: "  . $fName    . "<br />");
            echo("The lName is: "  . $lName    . "<br />");
            echo("The phone is: "  . $phone    . "<br />");
            echo("The gender is: " . $gender   . "<br />");
            echo("The Sponsor is: "  . $sponsor . "<br />");
            echo("Row count is: "  . $rowCount . "<br />");
        }
        //Free results
        $stmt->free_result();
        //close the statement
        $stmt->close();

      }//end of if($conn->prepare($sql))
       // Create an associative array mirroring the record in the HTML table
       // This will be used to populate the text boxes with the current runner info
      /*$thisRunner = [
           "id_runner" => $row['id_runner'],
           "fName" => $row['fName'],
           "lName" => $row['lName'],
           "phone" => $row['phone'],
           "gender" => $row['gender'],
           "sponsor" => $row['sponsorName']
        ]; */
        $thisRunner = [
            "id_runner" => $idRunner,
            "fName" => $fName,
            "lName" => $lName,
            "phone" => $phone,
            "gender"=> $gender,
            "sponsor" => $sponsor
           ];
      // Save array as a serialized session variable
      $_SESSION['sessionThisRunner'] = urlencode(serialize($thisRunner));

    } // end if lstRunner
    
    // Determine which button may have been clicked
    switch($_POST['btnSubmit']){
    // = = = = = = = = = = = = = = = = = = = 
    // DELETE  
    // = = = = = = = = = = = = = = = = = = = 
    case 'delete':
      //displayMessage("DELETE button pushed.", "green");
      
      //Make sure a runner has been selected.
      if($_POST["txtFName"] == "") {
         displayMessage("Please select a runner's name.", "red");
      } else {
        //Original unsafe sql 
        //$sql = "DELETE FROM runner WHERE id_runner = " . $thisRunner["id_runner"];
         //$result = $conn->query($sql);
         $sql = "DELETE FROM runner WHERE id_runner = ?";
         //Prepare
         if($stmt = $conn->prepare($sql)) {
            //bind the parameters
            $stmt->bind_param("i", $thisRunner['id_runner']);
            if($stmt->errno) {
                displayMessage("stmt prepare() had error.", "red");
            }
            //execute the query
            $stmt->execute();
            if($stmt->errno) {
                displayMessage("Could not execute prepared statement", "red");
            }
            //free results
            $stmt->free_result();
            //close statement
            $stmt->close();
         } //end if(prepare())
         // Remove any records in Table:sponsor
         $sql = "DELETE FROM sponsor WHERE id_runner = " . $thisRunner["id_runner"];
         $result = $conn->query($sql); 
         if($result) {
            displayMessage($thisRunner['fName'] . " " . $thisRunner['lName'] . " deleted.", "green");
         }
      }
      // Zero out the current selected runner
      clearThisRunner( );
      break;
    // = = = = = = = = = = = = = = = = = = = 
    // ADD NEW RUNNER 
    // = = = = = = = = = = = = = = = = = = = 
    case 'new':
       // Check for duplicate names using fName, lName, and phoneNumber
       //Original unsafe SQL
       /*
       $sql = "SELECT COUNT(*) AS total FROM runner 
       WHERE fName='" . $_POST['txtFName'] . "'
       AND   lName='" . $_POST['txtLName'] . "'
       AND   phone='" . unformatPhone($_POST['txtPhone']) . "'";

       $result = $conn->query($sql);
       $row=$result->fetch_assoc();
        */
        //Get the data from the post request
        //used to check for duplicates as well as to insert a new record
        $fName = $_POST['txtFName'];
        $lName = $_POST['txtLName'];
        $phone = unformatPhone($_POST['txtPhone']);
        $gender = $_POST['lstGender'];
        $sql = "SELECT fName, lName, phone FROM runner WHERE fName=? AND lName=? AND phone=?";
        
        //Set up a prepared statement
        if($stmt = $conn->prepare($sql)) {
            //pass the parameters
            echo "/$fName is: $fName<br/>";
            echo "\$lName is: $lName<br />";
            echo "\$phone is: $phone<br />";
            $stmt->bind_param("sss", $fName, $lName, $phone);
            if($stmt->errno) {
                displayMessage("stmt prepare() had error.", "red");
            }
            //execute the query
            $stmt->execute();
            if($stmt->errno) {
                displayMessage("Could not execute prepared statement", "red");
            }
            //store the result
            $stmt->store_result();
            $totalCount = $stmt->num_rows;
            //free result
            $stmt->free_result();
            //close
            $stmt->close();
        }// end if(prepare())
       // Runner already registered?
       if($row['total'] > 0) {
          displayMessage("This runner is already registered.", "red");
       }  
       //No duplicates
       else { 
          // Check for empty name fields or phone 
          if ($_POST['txtFName']=="" 
              || $_POST['txtFName']==""
              || $_POST['txtPhone']=="") {
            displayMessage("Please type in a first and last name and a phone number.", "red");
          }
          // First name and last name are populated
          else {
          // Add to Table:runner
          // Original Unsafe SQL
            /* $sql = "INSERT INTO runner (id_runner, fName, lName, phone, gender)
            VALUES (NULL, '" 
            . $_POST['txtFName'] ."', '" 
            . $_POST['txtLName'] ."', '"
            . unformatPhone($_POST['txtPhone']) ."', '"
            . $_POST['lstGender']."')";
            */

            $sql = "INSERT INTO runner (id_runner, fName, lName, phone, gender) VALUES (NULL, ?,?,?,?)";
            // Set up a prepared statement
            if($stmt = $conn->prepare($sql)) {
            // Pass the parameters
            $stmt->bind_param("ssss", $fName, $lName, $phone, $gender) ;
            if($stmt->errno) {
                displayMessage("stmt prepare( ) had error.", "red" ); 
            }
            
            // Execute the query
            $stmt->execute();
            if($stmt->errno) {
                displayMessage("Could not execute prepared statement", "red" );
            }
            
            // Free results
            $stmt->free_result( );
            // Close the statement
            $stmt->close( );
            } // end if( prepare( ))          
          // Add to Table:sponsor containing the foreign key id_runner
          /*
          $sql = "INSERT INTO sponsor (id_sponsor, sponsorName, id_runner) 
          VALUES (NULL,'" .$_POST['txtSponsor'] ."', 
             (SELECT id_runner 
                FROM runner 
                WHERE fName='" . $_POST['txtFName'] . "' 
                AND lName='"   . $_POST['txtLName'] . "'
              )
           )";
          $result = $conn->query($sql);
          */
          
          
          $sql = "INSERT INTO sponsor (id_sponsor, sponsorName, id_runner)
                  VALUES (NULL, ?, (SELECT id_runner FROM runner
                                    WHERE fname = ? AND lname = ?))";
          if($stmt=$conn->prepare($sql)) {
            $stmt->bind_param("sss", $_POST['txtSponsor'], $_POST['txtFName'], $_POST['txtLName']);
            if($stmt->errno) {
                displayMessage("stmt prepare() has error.", "Red");
            }
            $stmt->execute();
            if($stmt->errno) {
                displayMessage("Couldn't execute prepared statement.", "Red");
            }
            $stmt->free_result();
            $stmt->close();
          }


          
         }
         // Zero out the current selected runner
         clearThisRunner( );
       } // end of if/else($total > 0)
       break;
    
    // = = = = = = = = = = = = = = = = = = = 
    // UPDATE   
    // = = = = = = = = = = = = = = = = = = = 
    case 'update':
      //displayMessage("UPDATE button pushed.", "green");
      // Check for empty name 
     if ($_POST['txtFName']=="" || $_POST['txtLName']=="") {
        displayMessage("Please select a runner's name.", "red");
     }
     // First name and last name are selected
     else {
         $isSuccessful = false;
         // Update Table:runner
         /*
         $sql = "UPDATE runner SET fName='" . $_POST['txtFName'] . "', "
         . " lName = '" . $_POST['txtLName'] . "', "
         . " phone = '" . unformatPhone($_POST['txtPhone']) . "', "
         . " gender = '" . $_POST['lstGender'] . "' 
         WHERE id_runner = " . $thisRunner['id_runner'];
         $result = $conn->query($sql);
        */
        /* Prepared statement
        $sql = "UPDATE runner SET fName = ?, lName = ?, phone = ?, gender = ?
                WHERE id_runner = ?";
        if($stmt=$conn->prepare($sql)) {
            $stmt->bind_param("sssss", $_POST['txtFName'], $_POST['txtLName'], 
            unformatPhone($_POST['txtPhone']), $_POST['lstGender'], $thisRunner['id_runner']);
            if($stmt->errno) {
                displayMessage("stmt prepare() has error.", "Red");
            }
            $stmt->execute();
            if($stmt->errno) {
                displayMessage("Couldn't execute prepared statement.", "Red");
            }
            $stmt->free_result();
            $stmt->close();
        }
        */

        //Stored Procedure
        $sql = "CALL updateRunner(?, ?, ?, ?, ?)";
        if ($stmt = $conn->prepare($sql)) {
            // Bind the input parameters
            $stmt->bind_param("sssss", $_POST['txtFName'], $_POST['txtLName'], $thisRunner['phone'], $_POST['lstGender'], $thisRunner['id_runner']);
            if ($stmt->errno) {
                displayMessage("stmt prepare() has error.", "Red");
            }
            // Execute the stored procedure
            $stmt->execute();
            if ($stmt->errno) {
                displayMessage("Couldn't execute prepared statement.", "Red");
            } else {
                $isSuccessful = true;
            }
            $stmt->free_result();
            $stmt->close();
        }
        
        /*
         if($result) {
            $isSuccessful = true;
         }
         */
         if($stmt) {
            $isSuccessful = true;
         }
         // Update Table:sponsor
         // !!!! Does not update sponsor unless an entry already exists in the table !!!!
         $sql = "UPDATE sponsor SET sponsorName='" . $_POST['txtSponsor'] . "' WHERE id_runner = " . $thisRunner['id_runner'];
         $result = $conn->query($sql);
         if(!$stmt) {
            $isSuccessful = false;
         }
         // If successful update the variables
         if($isSuccessful) {
            displayMessage("Update successful!", "green");
            //$thisRunner['id_runner'] = $_POST['id_runner'];
            $thisRunner['fName']  = $_POST['txtFName'];
            $thisRunner['lName']  = $_POST['txtLName'];
            $thisRunner['phone']  = unformatPhone($_POST['txtPhone']);
            $thisRunner['gender'] = $_POST['lstGender'];
            $thisRunner['sponsor']= $_POST['txtSponsor'];
   
            // Save array as a serialized session variable
            $_SESSION['sessionThisRunner'] = urlencode(serialize($thisRunner));
         }
      }
      // Zero out the current selected runner
      clearThisRunner( );
      break;
   } // end of switch( )
    
}
else // or, a first time visitor?
{
    //echo '<h1>Welcome FIRST TIME</h1>';
} // end of if new else returning
?>

</head>
<body>
<div id="frame">
<h1>SunRun Registration</h1>

<form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>"
  method="POST"
  name="frmRegistration"
  id="frmRegistration">

 <label for="lstRunner"><strong>Select Runner's Name</strong></label>

 <select name="lstRunner" id="lstRunner" onChange="this.form.submit();">
    <option value="new">Select a name</option>
    <?PHP
       // Loop through the runner table to build the <option> list
       $sql = "SELECT id_runner, CONCAT(fName,' ',lName) AS 'name' 
       FROM runner ORDER BY lName";
       $result = $conn->query($sql);
       while($row = $result->fetch_assoc()) {    
          echo "<option value='" . $row['id_runner'] . "'>" . $row['name'] . "</option>\n";
       }
    ?>
   </select> 
   &nbsp;&nbsp;<a href="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>">New</a>
   <br />
   <br />
   
   <fieldset>
  <legend>Runner's Information</legend>
        
  <div class="topLabel">
     <label for="txtFName">First Name</label>
     <input type="text" name="txtFName"   id="txtFName"   value="<?php echo $thisRunner['fName']; ?>" />
     
  </div>
  
  <div class="topLabel">
     <label for="txtLName">Last Name</label>
     <input type="text" name="txtLName"   id="txtLName"   value="<?php echo $thisRunner['lName']; ?>" />
  </div>
  
  <div class="topLabel">
     <label for="txtPhone">Phone</label>
     <input type="text" name="txtPhone"   id="txtPhone"   value="<?php echo formatPhone($thisRunner['phone']); ?>" />
  </div>
  
  <div class="topLabel">
     <label for="lstGender">Gender</label>
     <select name="lstGender" id="lstGender">
        <option value="female">Female</option>
        <option value="male">Male</option>
     </select> 
  </div>
  
  <div class="topLabel">
     <label for="txtSponsor">Sponsor</label>
     <input type="text" name="txtSponsor" id="txtSponsor" value="<?php echo $thisRunner['sponsor']; ?>" />
  </div>
   </fieldset>
   
   <br />
   <button name="btnSubmit" 
       value="delete"
       style="float:left;"
       onclick="this.form.submit();">
       Delete
   </button>
      
   <button name="btnSubmit"    
       value="new"  
       style="float:right;"
       onclick="this.form.submit();">
       Add New Runner Information
   </button>
      
   <button name="btnSubmit" 
       value="update" 
       style="float:right;"
       onclick="this.form.submit();">
       Update
   </button>
   <br />     
  <!-- Use a hidden field to tell server if return visitor -->
  <input type="hidden" name="hidIsReturning" value="true" />
</form>
<br /><br />
<h2>Registered Runners</h2>
<?PHP
   displayRunnerTable( );
   echo "<br />"; 
?>
<script>
   // Populate the drop-down box with current value
   document.getElementById("lstGender").value = "<?PHP echo $thisRunner['gender']; ?>";
</script>

<h2>Explain prepared statements as one good defense against SQL Injection</h2>
<p>Prepared statements work by sending the prepared statement to the server as it's own entity with placeholder values.
    Then it sends the values (user input or otherwise) as plain text and not actually part of the SQL query preventing any injection. 
</p>
<h2>Explain control of user input</h2>
<p>This is done through a technique called input sanitization. Essentially it takes any characters that are not plain text and 
    turns them into their unicode counterparts so that they are interpreted as plain text. Since h1 would not show up as h1 there
    would be no change to the format. That said, there is ways to only block specific characters which means you could allow 
    the use of h1 if desired.
</p>
</div>
</body>
</html>