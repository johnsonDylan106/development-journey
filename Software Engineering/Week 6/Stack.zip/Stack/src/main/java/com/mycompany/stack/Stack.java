/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.stack;

/**
 *
 * @author dylan
 */
public class Stack<E> {
    
    private E array[];
    private int size;

    public Stack() throws Exception {
        array = (E[]) new Object[20];
        size = 0;
    }

    public Stack(int capacity) {
        if (capacity < 0) {
            array = (E[]) new Object[20];
        } else {
            array = (E[]) new Object[capacity];
        }
        size = 0;
    }

    public E pop() throws EmptyStackException {
        if (size == 0) {
            throw new EmptyStackException();
        }
        E data = array[size - 1];
        size--;
        return data;
    }

    public E peek() throws EmptyStackException {
        if (size == 0) {
            throw new EmptyStackException();
        }
        return array[size - 1];
    }

    public void push(E item) throws FullStackException {
        if (size == array.length) {
            throw new FullStackException();
        }
        array[size] = item;
        size++;
    }

    public boolean empty() {
        return size == 0;
    }
}

class FullStackException extends Exception {
    public FullStackException() {
        super("Stack is full!");
    }
}

class EmptyStackException extends Exception {
    public EmptyStackException() {
        super("Stack is empty!");
    }
}
