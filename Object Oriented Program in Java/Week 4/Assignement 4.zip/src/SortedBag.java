import java.util.ArrayList;

public class SortedBag<Items> implements iBag<Items> {

	ArrayList<Items> Sorted = new ArrayList<>();
	
	@Override
	public void add(Items item) {//adds item to bag
		Sorted.add(item);
	}

	@Override
	public Items remove() {//removes item from bag bag
		return null;
	}

	@Override
	public boolean contains(Items item) { //checks if item exists
		
		if (Sorted.contains(item)) {
			return true;
		}else {
			return false;
		}
	}

	@Override
	public boolean empty() { //checks if bag is empty
		if (Sorted.size() == 0) {
			return true;			
		}else {return false;}
	}
	
	public void sort() { //sorts items in the bag -- really the only difference between sorted and unsorted classes
		Sorted.sort(null);
	}
	
	public void printArray() { //prints out all items in the bag
		for (Items value: Sorted) {
			System.out.println(value);
		}
	}
	
	public int arraySize() { //returns the number of items in the bag
		return Sorted.size();
	}
	
	public Items getItem(int item) { //returns a specific item in the bag
		return Sorted.get(item);
	}
	
	public void remove(int item) { //removes given item from the bag
		Sorted.remove(item);
	}

}
