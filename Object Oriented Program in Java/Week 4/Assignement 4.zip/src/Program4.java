/*
 * Dylan Johnson
 * CSC322
 * Assignment 4
 * 
 *  I certify, that this computer program submitted by me is all of my own work. Signed: Dylan Johnson
 *  
 *  With the requirements of this assignment I don't think that having 2 different classes for sorted and unsorted
 *  was necessary. Could have gotten rid of the interface, had one class for the bag, and another one to call a sort
 *  function for if it was needed. I get why it was here as a learning tool but I almost went the other way.
 */

import java.util.ArrayList;
import java.util.Scanner;

public class Program4 {

	public static void main(String[] args) {
		
		run();//starts the program

	}
	
	public static Scanner input = new Scanner(System.in);//global access scanner variable
	public static void run() {
		
		String bagType = getBagType();//gets bag type
		if (bagType.equalsIgnoreCase("Sorted")) {//if sorted run the sorted function
			sortedBag();			
		}else if (bagType.equalsIgnoreCase("Unsorted")) {//if unsorted, run the unsorted function
			unSortedBag();			
		}//no else required because it is caught in the getBagType() function

		
		
	}


	//Unsorted bag class--------------------------------------------------------
	private static void unSortedBag() {
		unSortedBag<String> unSorted = new unSortedBag<>();
		System.out.print("\nNumber of items going into the bag: ");
		int items = input.nextInt();
		input.nextLine();
		
		//Enters every item into the bag-------------------------
		for(int i=0; i<items; i++) {
			System.out.print("Enter item " + (i+1) + ": ");
			unSorted.add(input.nextLine());
		}
		//-------------------------------------------------------
					
		System.out.println("\nYou can check if something is in the bag.");
		System.out.println("Type 'done' to stop");
		String checkForItem;
		
		//Checks if item is in the bag-----------------------------------
		do {
			System.out.print("Check for: ");
			checkForItem = input.nextLine();
			boolean result = unSorted.contains(checkForItem);
			if (checkForItem.equalsIgnoreCase("done")) {
				break;
			}
			else if (result == true) {
				System.out.println("Yes, it's in the bag.");
			}else {
				System.out.println("No, it's not in the bag.");
			}
		}while(!checkForItem.equalsIgnoreCase("done"));
		//---------------------------------------------------------------
		
		
		System.out.println("\nLet's remove stuff from the bag:");
		int arraySize = unSorted.arraySize();
		//Prints and removes items from the bag---------------------------
		for (int i = 0; i < arraySize; i++) {
			System.out.println("Removing item: " + unSorted.getItem(0));
			unSorted.remove(0);
		}
		//----------------------------------------------------------------
	}
	//-------------------------------------------------------------------------


	//Sorted Bag output class ---------------------------------------------------
	private static void sortedBag() {
		SortedBag<String> Sorted = new SortedBag<>();
		System.out.print("\nNumber of items going into the bag: ");
		int items = input.nextInt();
		input.nextLine();
		
		//Allows user to enter each item of the bag-------------
		for(int i=0; i<items; i++) {
			System.out.print("Enter item " + (i+1) + ": ");
			Sorted.add(input.nextLine());
		}
		//------------------------------------------------------
		
		Sorted.sort(); //Sorts the items
					
		System.out.println("\nYou can check if something is in the bag.");
		System.out.println("Type 'done' to stop");
		String checkForItem;
		
		//Checks if item in bag exists-----------------------------
		do {
			System.out.print("Check for: ");
			checkForItem = input.nextLine();
			boolean result = Sorted.contains(checkForItem);
			if (checkForItem.equalsIgnoreCase("done")) {
				break;
			}
			else if (result == true) {
				System.out.println("Yes, it's in the bag.");
			}else {
				System.out.println("No, it's not in the bag.");
			}
		}while(!checkForItem.equalsIgnoreCase("done"));
		//---------------------------------------------------------
		
		
		System.out.println("\nLet's remove stuff from the bag:");
		int arraySize = Sorted.arraySize();
		
		//Prints and removes every item from the bag array--------------
		for (int i = 0; i < arraySize; i++) {
			System.out.println("Removing item: " + Sorted.getItem(0));
			Sorted.remove(0);
		}
		//--------------------------------------------------------------
	}
	//--------------------------------------------------------------------------
	
	// Returns what type of bag is being requested by the user---------
	private static String getBagType() {
		ArrayList<String> options = new ArrayList<>();
		options.add("Sorted");
		options.add("Unsorted");
		options.add("sorted");
		options.add("unsorted");
		String bagType;
		do {
			System.out.println("Which type of bag do you want?");
			System.out.print("Sorted or Unsorted: ");
			bagType = input.nextLine();
		} while (!options.contains(bagType));
		options.clear();
		return bagType;
	}
	//------------------------------------------------------------------
	

}
