//Main interface of the program
//any class that inherits this has to incorporate all aspects below
interface iBag<Items> {
	
	public void add(Items item);
	public Items remove();
	public boolean contains(Items item);
	public boolean empty();
	
}
