//see SortedBag class for comments

import java.util.ArrayList;

public class unSortedBag<Items> implements iBag<Items> {

ArrayList<Items> Sorted = new ArrayList<>();
	
	@Override
	public void add(Items item) {
		Sorted.add(item);
	}

	@Override
	public Items remove() {
		return null;
	}

	@Override
	public boolean contains(Items item) {
		
		if (Sorted.contains(item)) {
			return true;
		}else {
			return false;
		}
	}

	@Override
	public boolean empty() {
		if (Sorted.size() == 0) {
			return true;			
		}else {return false;}
	}
	
	public void printArray() {
		for (Items value: Sorted) {
			System.out.println(value);
		}
	}
	
	public int arraySize() {
		return Sorted.size();
	}
	
	public Items getItem(int item) {
		return Sorted.get(item);
	}
	
	public void remove(int item) {
		Sorted.remove(item);
	}

}
