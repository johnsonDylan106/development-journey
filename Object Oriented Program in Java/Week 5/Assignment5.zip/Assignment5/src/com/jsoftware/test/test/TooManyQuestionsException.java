package com.jsoftware.test.test;

/*
 * This class is just here to catch if there is too many questions
 * in a sample set in the testTaker program.
 */

public class TooManyQuestionsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	
}
