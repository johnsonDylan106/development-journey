/*
 * Dylan Johnson
 * CSC322
 * Assignment 5
 * 
 *  I certify, that this computer program submitted by me is all of my own work. Signed: Dylan Johnson
 * 
 */

package com.jsoftware.test;

import java.io.IOException;

import com.jsoftware.test.test.whichTest;

public class start {

	public static void main(String[] args) throws IOException {
		new whichTest();

	}

}
