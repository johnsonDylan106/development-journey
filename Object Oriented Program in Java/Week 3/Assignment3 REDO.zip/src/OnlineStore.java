import java.util.Scanner;

public class OnlineStore {

	//public static ArrayList<itemInventory> inventory = new ArrayList<>();
	public static Scanner input = new Scanner(System.in);
	
	private itemInventory ie;

	public void start() {
		
		ie = itemInventory.load("data");
		getChoice();
		shutDown();
	}

	private void getChoice() {
		
		int choice;
		do {
			choice = menu();
			if (choice != 5) {
				printHeader();
				printTable(choice);
				printFooter();
			}
		}while(choice != 5);
		
	}
	
	private int menu() {
		
		int choice;
		System.out.println("Welcome to eMart");
		System.out.println("  1) Show all items");
		System.out.println("  2) Show only music CD");
		System.out.println("  3) Show only books");
		System.out.println("  4) Show only software");
		System.out.println("  5) Exit program");
		System.out.print("Choice: ");
		choice = input.nextInt();
		input.nextLine();
		System.out.println("\n\n");
		return choice;
		
	}
	
	private void printTable(int choice) {
		
		if (choice == 1) {	
			for (itemEntry itemEntry:ie.getItems()) {
				printLine(itemEntry);
			}
		}else if (choice == 2) {
			for (itemEntry itemEntry:ie.getItems()) {
				if (itemEntry.getItem() instanceof music) {
					printLine(itemEntry);
				}
			}
		}else if (choice == 3) {
			for (itemEntry itemEntry:ie.getItems()) {
				if (itemEntry.getItem() instanceof book) {
					printLine(itemEntry);
				}
			}
		}else if (choice == 4) {
			for (itemEntry itemEntry:ie.getItems()) {
				if (itemEntry.getItem() instanceof software) {
					printLine(itemEntry);
				}
			}
		}
			
		
	}
	
	private void printLine(itemEntry itemEntry) {
		item item = itemEntry.getItem();
		System.out.printf("| %-30s | %-10s | $%-9.2f | %-10d |\n", item.getTitle(), itemEntry.getType(), item.getPrice(), itemEntry.getQuantity());
	}

	private void printFooter() {
		System.out.printf("%75s\n\n", "-".repeat(75));
	}

	private void printHeader() {
		System.out.printf("%75s\n", "-".repeat(75));
		System.out.printf("| %-30s | %-10s | %-10s | %-10s |\n", "Title", "Type", "Price", "Quantity");
		System.out.printf("%75s\n", "-".repeat(75));
	}
	
	private void shutDown() {
		System.out.println("Shutting Down..");
	}
	
}
