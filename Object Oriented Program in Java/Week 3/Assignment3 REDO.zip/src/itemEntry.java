
public class itemEntry {

	private item item;
	private String type;
	private int quantity;
	
	public itemEntry(item item, String type, int quantity) {
		this.item = item;
		this.type = type;
		this.quantity = quantity;
	}
	
	public item getItem() {
		return item;
	}
	
	public String getItemName() {
		return item.getTitle();
	}
	
	public double getPrice() {
		return item.getPrice();
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public String getType() {
		return type;
	}
	
}
