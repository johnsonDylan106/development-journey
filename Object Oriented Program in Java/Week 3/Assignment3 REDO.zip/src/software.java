
public class software extends item{

	String version;
	
	public software(String title, double price, String version) {
		super(title, price);
		this.version = version;
	}
	
}
