import java.util.ArrayList;
import java.time.LocalDate;

public class itemInventory {


	private static ArrayList<String> data = new ArrayList<>();
	private static ArrayList<String> temp = new ArrayList<>();
	private ArrayList<itemEntry> inventory;
	
	private itemInventory() {
		inventory = new ArrayList<>();
	}
	
	public static itemInventory load(String fileName) {
		itemInventory itemInventory = new itemInventory();
		ReadFile input = new ReadFile();

		input.readFile(fileName, data);

		if (data.get(0).equals("No Such File")) {

			System.out.println("Please enter a valid file name.");
			System.exit(0);

		} else {
			
			
			for(String value: data) {
				temp.clear();
				for(String test: value.split("\\|")) {
					temp.add(test);
				}
			
				itemEntry itemEntry = null;
				
				if (temp.get(0).equals("music")) {
					//itemInventory itemInventory = new itemInventory();
					String title = temp.get(1), artist = temp.get(2), label = temp.get(4), recordCompany = temp.get(5), genre = temp.get(7), type = temp.get(0);
					double price = Double.parseDouble(temp.get(8));
					int totalLength = Integer.parseInt(temp.get(6)), quantity = Integer.parseInt(temp.get(9));
					//Calendar calendar = Calendar.getInstance();
					String[] fullDate = temp.get(3).split("/");
					int year = Integer.parseInt(fullDate[2]);
					int month = Integer.parseInt(fullDate[0]);
					int date = Integer.parseInt(fullDate[1]);
					//calendar.set(year,month,date);
					LocalDate releaseDate = LocalDate.of(year, month, date);//calendar.getTime();
					
					music music = new music(title,price,artist,releaseDate,label,recordCompany,totalLength,genre);
					itemEntry = new itemEntry(music, type, quantity);

					
				}else if (temp.get(0).equals("software")) {
					
					String title = temp.get(1), version = temp.get(2), type = temp.get(0);
					double price = Double.parseDouble(temp.get(3));
					int quantity = Integer.parseInt(temp.get(4));
					software software = new software(title, price, version);
					itemEntry = new itemEntry(software, type, quantity);
					
					
					
				}else if (temp.get(0).equals("book")) {
					
					String title = temp.get(1), author = temp.get(2), edition = temp.get(3), publisher = temp.get(4), type = temp.get(0);
					double price = Double.parseDouble(temp.get(6));
					int quantity = Integer.parseInt(temp.get(7)), pubYear = Integer.parseInt(temp.get(5));
					book book = new book(title, price, author, edition, publisher, pubYear);
					itemEntry = new itemEntry(book, type, quantity);
					
				}
			
				itemInventory.inventory.add(itemEntry);
				
			}
		}
		return itemInventory;
	}
	
	public ArrayList<itemEntry> getItems() {
		return inventory;
		}
	
}
