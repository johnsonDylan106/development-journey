
public class book extends item{
	
	String author;
    String edition;
    String publisher;
    int pubYear;
    
    public book(String title, double price, String author, String edition, String publisher, int pubYear) {
    	super(title, price);
    	this.author = author;
    	this.edition = edition;
    	this.publisher = publisher;
    	this.pubYear = pubYear;

    }

}
