
public class Assignment3 {

	public static void main(String[] args) {
		new OnlineStore().start();

	}

}
