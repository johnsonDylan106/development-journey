import java.time.LocalDate;

public class music extends item{

	String artist;
	LocalDate releaseDate;
	String label;
	String recordCompany;
	int albumLength;
	String genre;
	
	public music(String title, double price, String artist, LocalDate releaseDate, String label, String recordCompany, 
			int albumLength, String genre) {
		super(title, price);
		this.artist = artist;
		this.releaseDate = releaseDate;
		this.label = label;
		this.recordCompany = recordCompany;
		this.albumLength = albumLength;
		this.genre = genre;

	}

}
