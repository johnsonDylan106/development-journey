package hashPass1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class main {

	public static void main(String[] args) {
		
		// Required header for class -------------------------------------------------
		System.out.println("Submitted by Dylan Johnson - johnsond47@csp.edu");
		System.out.println("I certify that this is my own work.");
		//----------------------------------------------------------------------------
		
		ArrayList<credential> credentials = new ArrayList<>(); // ArrayList of credential objects
		credentials = login.fillUsers("unencryptedPasswords", credentials); // Pulls in provided text file and stores in created ArrayList
		credentials.trimToSize();
		
		// Sorts the objects required by assignment and prints them out ----------------
		Collections.sort(credentials, Comparator.comparing(credential::getUser));
		printTable(credentials, "Users");
		Collections.sort(credentials, Comparator.comparing(credential::getPass));
		printTable(credentials, "Passwords");
		Collections.sort(credentials, Comparator.comparing(credential::getHashPass));
		printTable(credentials, "Hashed Passwords");
		//------------------------------------------------------------------------------
		
	}

	private static void printTable(ArrayList<credential> credentials, String header) {
		System.out.println("\n\nDisplay Sorted " + header + "\n--------------");
		for (credential user : credentials) {
			user.assignmentPrint();
			System.out.println();
		}
	}

}
