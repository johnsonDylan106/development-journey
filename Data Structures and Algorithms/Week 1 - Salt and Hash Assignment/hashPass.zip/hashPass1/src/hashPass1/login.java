package hashPass1;

import java.util.ArrayList;

public class login {
	
	public static ArrayList<credential> fillUsers(String fileName, ArrayList<credential> credentials) {		
			
			ArrayList<String> loginFile = new ArrayList<>();
			ReadFile read = new ReadFile();
			read.readFile(fileName, loginFile);
			
			
			ArrayList<existingUser> userSalt = new ArrayList<>();
			userSalt = existingUsers.getUsers(userSalt);
			
			for (String user : loginFile) {
				
				String[] info = user.split("\\|"); // Splits imported data on "|" delimiter
				byte[] tempByte = existingUsers.checkSalt(info[0], userSalt);
				byte[] salt = null;
				String tempHashed = existingUsers.checkHash(info[0], userSalt);
				String hashed = null; 
				if (tempByte == null && tempHashed == null) {
					// this would be dependent on new user or existing user
					// If existed do not generate, pull secure location and compare
					// If new generate new and save
					int saltNum = read.readInt("number");
					salt = PasswordHasher.makeSalt(saltNum); // Provided code to generate salt				
					hashed = PasswordHasher.makeHashedPassword(info[1], salt); // Provided code to generated hashed password
					outFile.writeToFile("file", info[0], hashed, salt); // Only writes info for new users
				} else {
					salt = tempByte;
					hashed = tempHashed;
				}
				
				
				
				credential cred = new credential(info[0], info[1], hashed, salt); // Creates new object based on imported data
				credentials.add(cred); // Stores that info in the arrayList
				
				
			}
			
			return credentials;
			
		}

}
