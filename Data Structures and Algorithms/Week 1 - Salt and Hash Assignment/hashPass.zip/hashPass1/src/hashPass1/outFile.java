package hashPass1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;


public class outFile {

    public static void writeToFile(String fileName, String user, String hashed ,byte[] salt) {
//    	String filePath = fileName + ".txt";
//        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
//            writer.write("\n" + user + "|" + hashed + "|" + salt);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        
        
        String filePath = fileName + ".txt";

        try {
            // Checking if the file exists
            File file = new File(filePath);
            boolean appendNewLine = file.exists();

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, appendNewLine))) {
                if (appendNewLine) {
                    writer.newLine(); // Add a new line if appending to an existing file
                }

                writer.write(user + "|" + hashed + "|" + salt);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }    
    
}

