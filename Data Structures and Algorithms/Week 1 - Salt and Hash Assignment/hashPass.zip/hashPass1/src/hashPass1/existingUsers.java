package hashPass1;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

public class existingUsers {

	public static ArrayList<existingUser> getUsers(ArrayList<existingUser> userSalt) {
		
		ArrayList<String> getSalt = new ArrayList<>();
		ReadFile read = new ReadFile();
		Path path = Paths.get("file.txt");
		if (Files.exists(path)) {
			getSalt = read.readFile("file", getSalt);			
			for (String salt : getSalt) {
				String[] temp = salt.split("\\|");
				byte[] s = null;
				s = temp[2].getBytes();
				existingUser temp1 = new existingUser(temp[0], temp[1], s);
				userSalt.add(temp1);
			}
		}
		return userSalt;
	}
	
	public static byte[] checkSalt(String user, ArrayList<existingUser> userSalt) {
		
		for (existingUser userName : userSalt) {
		
			if (userName.getUser().equals(user)) {
				return userName.getSalt();				
			}
		}
		return null;
	}
	
	public static String checkHash(String user, ArrayList<existingUser> userSalt) {
		
		for (existingUser userName : userSalt) {
		
			if (userName.getUser().equals(user)) {
				return userName.getHash();
			}
		}
		return null;
	}
	
}
