package hashPass1;

public class existingUser {

	public String user;
	public String hash;
	public byte[] salt;
	
	public existingUser(String user, String hash, byte[] salt) {
		this.user = user;
		this.hash = hash;
		this.salt = salt;
	}
	
	public String getUser() {
		return user;
	}
	
	public byte[] getSalt() {
		return salt;
	}
	
	public String getHash() {
		return hash;
	}
	
}
