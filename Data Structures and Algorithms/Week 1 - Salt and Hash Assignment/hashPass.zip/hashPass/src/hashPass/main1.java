package hashPass;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class main1 {

	public static void main(String[] args) {
		
		// Required header for class -------------------------------------------------
		System.out.println("Submitted by Dylan Johnson - johnsond47@csp.edu");
		System.out.println("I certify that this is my own work.");
		//----------------------------------------------------------------------------
		
		ArrayList<credential> credentials = new ArrayList<>(); // ArrayList of credential objects
		credentials = getUsers("unencryptedPasswords", credentials); // Pulls in provided text file and stores in created ArrayList
		
		
		// Sorts the objects required by assignment and prints them out ----------------
		Collections.sort(credentials, Comparator.comparing(credential::getUser));
		printTable(credentials, "Users");
		Collections.sort(credentials, Comparator.comparing(credential::getPass));
		printTable(credentials, "Passwords");
		Collections.sort(credentials, Comparator.comparing(credential::getHashPass));
		printTable(credentials, "Hashed Passwords");
		//------------------------------------------------------------------------------
		
	}

	private static void printTable(ArrayList<credential> credentials, String header) {
		System.out.println("\n\nDisplay Sorted " + header + "\n--------------");
		for (credential user : credentials) {
			user.assignmentPrint();
			System.out.println();
		}
	}
	
	private static ArrayList<credential> getUsers(String fileName, ArrayList<credential> credentials) {		
		
		ArrayList<String> input = new ArrayList<>();
		ReadFile creds = new ReadFile();
		creds.readFile(fileName, input);
		
		
		
		for (String each : input) {
			
			String[] info = each.split("\\|"); // Splits imported data on "|" delimiter
			
			// this would be dependent on new user or existing user
			// If existed do not generate, pull secure location and compare
			// If new generate new and save
			byte[] salt = PasswordHasher.makeSalt(16); // Provided code to generate salt
			
			String hashed = PasswordHasher.makeHashedPassword(info[1], salt); // Provided code to generated hashed password
			
			credential cred = new credential(info[0], info[1], hashed, salt); // Creates new object based on imported data
			credentials.add(cred); // Stores that info in the arrayList
			
		}
		
		return credentials;
		
	}

}
