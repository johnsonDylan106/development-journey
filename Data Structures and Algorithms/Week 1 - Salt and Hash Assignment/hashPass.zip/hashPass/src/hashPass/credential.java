package hashPass;

public class credential {

	public String user;
	public String pass;
	public String hashPass;
	public byte[] salt;
	
	public credential(String user, String pass, String hashPass, byte[] salt) {
		this.user = user;
		this.pass = pass;
		this.hashPass = hashPass;
		this.salt = salt;
	}
	
	public void printCreds() {
		System.out.println(user);
		System.out.println(pass);
		System.out.println(hashPass);
		System.out.println(salt);
	}
	
	public void assignmentPrint() {
		System.out.println("User: " + user);
		System.out.println("\tPassword: " + pass);
		System.out.println("\tHashedPassword: " + hashPass);
		
	}
	
	public String getUser() {
		return user;
	}
	
	public String getPass() {
		return pass;
	}
	
	public String getHashPass() {
		return hashPass;
	}
	
	
}
