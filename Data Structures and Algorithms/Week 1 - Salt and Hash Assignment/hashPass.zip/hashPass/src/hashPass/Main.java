package hashPass;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Main {

	public static ArrayList<String> input = new ArrayList();
	public static ArrayList<ArrayList<String>> cred = new ArrayList();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Submitted by Dylan Johnson - johnsond47@csp.edu");
		System.out.println("I certify that this is my own work.");
		
		readFile();
		
		hashedPass();
		
		printSortedTables();
		
	}

	private static void printSortedTables() {
		ArrayList<String> header = new ArrayList();
		header.add("User");
		header.add("Password");
		header.add("HashedPassword");
		
		for (int x=0; x<3; x++) {
		
			int y = x;
			Collections.sort(cred, Comparator.comparing(list -> list.get(y)));
			
			System.out.println("\n\nDisplay Sorted " + header.get(y) + "s\n--------------");
			
			for (int i = 0; i < cred.size(); i++) {
	            for (int j = 0; j < cred.get(i).size(); j++) {
	            	if (j!=0) {
	                	System.out.print("\t");
	                }
	            	System.out.print(header.get(j) + ": ");
	            	System.out.print(cred.get(i).get(j) + "\n");
	            }
	        }
		}
	}

	private static void hashedPass() {
		for (int i=0; i<input.size(); i++) {
			String creds = input.get(i);
			String delimiter = "\\|";
			String[] splitCreds = creds.split(delimiter);
			
			//PasswordHasher hash = new PasswordHasher();
			byte[] salt = PasswordHasher.makeSalt(splitCreds[1].length());
			String hashed = PasswordHasher.makeHashedPassword(splitCreds[1], salt);
			
			ArrayList<String> splitData = new ArrayList();

			for (String each : splitCreds) {
				splitData.add(each);
			}
			splitData.add(hashed);
			cred.add(splitData);
		}
	}

	private static void readFile() {		
		ReadFile creds = new ReadFile();
		
		creds.readFile("unencryptedPasswords", input);
	}

}
