package bandCoordinator;

import java.util.ArrayList;

public class main {

	public static void main(String[] args) {
		
		System.out.println("Dylan Johnson johnsond47@csp.edu");
		System.out.println("I certify that this is my own work.\n\n");
		
		ArrayList<bandInfo> bandInfo = new ArrayList<>();
		bandInfo = getBandInfo.importInfo(bandInfo);	
		menu.printMenu(bandInfo);
		
	}

	

}
