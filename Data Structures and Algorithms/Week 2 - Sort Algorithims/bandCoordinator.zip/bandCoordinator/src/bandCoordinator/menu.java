package bandCoordinator;

import java.util.ArrayList;
import java.util.Scanner;

public class menu {

	public static void printMenu(ArrayList<bandInfo> bandInfo) {
		Scanner readUser = new Scanner(System.in);
		int choice = -1;
		
		System.out.println("What would you like to do?");
		while (choice != 0) {
			System.out.print("Search by:\n \t1. Band Name\n \t2. Single Count\n \t0. Exit\nChoice: ");
			choice = readUser.nextInt();
			readUser.nextLine();
			
			switch (choice) {
			
				case 0:
					System.out.println("Closing");
					break;
			
				case 1:
					System.out.print("\nEnter Band Name you are looking for: ");
					String bandName = readUser.nextLine();
					Search.binarySearch(bandInfo, bandName);
					break;
					
				case 2:
					System.out.print("\nEnter the Set Time you are looking for: ");
					int setTime = readUser.nextInt();
					readUser.nextLine();
					Search.linearSearch(bandInfo, setTime);
					break;
					
				default:
					System.out.println("Not a valid choice please try again");
				
			}
		}
		
		readUser.close();
	}
}
