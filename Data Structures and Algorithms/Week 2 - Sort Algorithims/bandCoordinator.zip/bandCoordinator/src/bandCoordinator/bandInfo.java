package bandCoordinator;

public class bandInfo {
	
	String bandName;
	int singleCount;
	
	public bandInfo(String bandName, int singleCount) {
		this.bandName = bandName;
		this.singleCount = singleCount;
	}
	
	
	public String getBandName() {
		return bandName;
	}
	
	public int getSingleCount() {
		return singleCount;
	}
	
	public String searchBandName() {
		return bandName.toLowerCase();
	}
	
}
