package bandCoordinator;

import java.util.ArrayList;

public class Search {

	public static void binarySearch(ArrayList<bandInfo> bandInfo, String searchFor) {
	
		int left = 0;
		int right = bandInfo.size() - 1;
		
		while (left <= right) {
			int mid = left + (right - left)/2;
			int compareResult = bandInfo.get(mid).searchBandName().compareTo(searchFor);
			
			if (compareResult == 0) {
				System.out.println("\nBand name is: " + bandInfo.get(mid).getBandName());
				System.out.println("Band found is: " + bandInfo.get(mid).getBandName() + " has " + bandInfo.get(mid).getSingleCount() + " singles\n");
				left = right + 1;
			} else if (compareResult < 0) {
				left = mid + 1;
			} else {
				right = mid - 1;
			}
			
		}
		
	}
	
	
	public static void linearSearch(ArrayList<bandInfo> bandInfo, int searchFor) {
		
		ArrayList<bandInfo> temp = new ArrayList<>();
		for (bandInfo band : bandInfo) {
			if (band.getSingleCount() >= searchFor - 5 && band.getSingleCount() <= searchFor + 5) {
				temp.add(band);
			}
		}
		
		if (temp.size() > 1) {
			temp = getBandInfo.sortBandSingles(temp, temp.size());
			System.out.println("There are " + temp.size() + " bands that closely match your critera: ");
			int i = 1;
			for (bandInfo band : temp) {
				System.out.println();
				System.out.print(i + ": " + band.getBandName() + " has " + band.getSingleCount() + " single");
				if (band.getSingleCount() > 1) {
					System.out.println("s");
				} else {System.out.println();}
				i++;
			}
			System.out.println();
		} else if (temp.size() == 1) {
			System.out.println("Band with the closest set time: " + temp.get(0).getBandName() + " has " + temp.get(0).getSingleCount() + " singles");
		} else {
			System.out.println("please refine your search");
		}
		
	}
	
}
