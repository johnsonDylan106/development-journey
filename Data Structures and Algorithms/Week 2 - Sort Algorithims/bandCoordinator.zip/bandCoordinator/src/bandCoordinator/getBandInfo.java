package bandCoordinator;

import java.util.ArrayList;

public class getBandInfo {
	
	//Pulls in the info from provided file------------------------------------------------
	public static ArrayList<bandInfo> importInfo(ArrayList<bandInfo> bandInfo) {
		ArrayList<String> importFile = new ArrayList<>();
		
		ReadFile read = new ReadFile();
		importFile = read.readFile("bandInfo", importFile);
		
		for (String band : importFile) {
			String[] temp = band.split("\\|");
			int singles = -1;
			
			try {
			    singles = Integer.parseInt(temp[1]);
			} catch (NumberFormatException e) {
			    System.err.println("Error: Single count provided not an integer.");
			    e.printStackTrace();
			    System.exit(1);
			}
			
			bandInfo temp1 = new bandInfo(temp[0], singles);
			
			bandInfo.add(temp1);		
		}
		
		//printBandNames(bandInfo);
		bandInfo = sortBandNames(bandInfo, bandInfo.size());
		//printBandNames(bandInfo);
		
		return bandInfo;
	}
	//-------------------------------------------------------------------------------------
	
	// Recursive sort to order the list of bands in an arrayList -------------------------------
	public static ArrayList<bandInfo> sortBandNames(ArrayList<bandInfo> bandInfo, int numToSort) {
				
		if(numToSort <= 1) {
			return bandInfo;
		}
		
		bandInfo = sortBandNames(bandInfo, numToSort - 1);
		
		bandInfo key = bandInfo.get(numToSort - 1);
		int j = numToSort - 2;
		
		
		while(j >= 0 && bandInfo.get(j).getBandName().compareTo(key.getBandName()) > 0) {
			bandInfo.set(j+1, bandInfo.get(j));
			j = j-1;
		}
		
		bandInfo.set(j+1, key);
		
		return bandInfo;
	}
	//------------------------------------------------------------------------------------------
	
	// Recursive sort to order the list of singles smallest to largetst in an arrayList -------------------------------
	public static ArrayList<bandInfo> sortBandSingles(ArrayList<bandInfo> bandInfo, int numToSort) {
				
		if(numToSort <= 1) {
			return bandInfo;
		}
		
		bandInfo = sortBandSingles(bandInfo, numToSort - 1);
		
		bandInfo key = bandInfo.get(numToSort - 1);
		int j = numToSort - 2;
		
		
		while(j >= 0 && bandInfo.get(j).getSingleCount() > key.getSingleCount()) {
			bandInfo.set(j+1, bandInfo.get(j));
			j = j-1;
		}
		
		bandInfo.set(j+1, key);
		
		return bandInfo;
	}
	//-----------------------------------------------------------------------------------------------------------------
	
	// For testing purposes
	public static void printBandNames(ArrayList<bandInfo> bandInfo) {
		System.out.println();
		for (bandInfo band : bandInfo) {
			System.out.println(band.getBandName());
		}
		System.out.println();
	}

}
