package radixSort;

import java.util.ArrayList;

public class main {

	public static void main(String[] args) {

		// Required header for class -------------------------------------------------
		System.out.println("Submitted by Dylan Johnson - johnsond47@csp.edu");
		System.out.println("I certify that this is my own work.\n\n");
		// ----------------------------------------------------------------------------

		ArrayList<String> input = new ArrayList<>();

		ReadFile read = new ReadFile();
		input = read.readFile("words", input);

		radixSort.radix(input);

	}



}
