package radixSort;

import java.util.ArrayList;

public class radixSort {

	public static void radix(ArrayList<String> sortFile) {
        int maxLength = 20; // Going as far as the 20th character in each line
        int charSetSize = 27; // 26 lowercase alphabet characters + space
        int numOfItems = sortFile.size();

        // Perform counting sort for each character position from 20th to 1st-----------------
        for (int position = maxLength - 1; position >= 0; position--) {
            
        	sortFile = countingSort.counting(sortFile, position, numOfItems, charSetSize);
            System.out.println("Iterating on index " + position + ":");

            printSorted(sortFile);
            
        }
        //-----------------------------------------------------------------------------------
    }

	// Prints out each sorted instance ----------------------------
	private static void printSorted(ArrayList<String> sortFile) {
		for (String line : sortFile) {
		    System.out.println(line);
		}
		System.out.println(); // Adds new line for formatting
	}
	//-------------------------------------------------------------
	
}
