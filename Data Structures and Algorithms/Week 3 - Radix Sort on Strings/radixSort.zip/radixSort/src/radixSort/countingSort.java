package radixSort;

import java.util.ArrayList;
import java.util.Collections;

public class countingSort {

	public static ArrayList<String> counting(ArrayList<String> sortFile, int position, int numOfItems,int charSetSize) {

		ArrayList<String> output = new ArrayList<>(Collections.nCopies(numOfItems, "")); // Initialize with empty
																							// strings
		ArrayList<Integer> count = new ArrayList<>(Collections.nCopies(charSetSize, 0)); // Initialize with zeros

		// Count occurrences of each character in the current
		// position-----------------------
		for (int i = 0; i < numOfItems; i++) {

			char currentChar;
			if (position < sortFile.get(i).length()) {
				currentChar = sortFile.get(i).charAt(position);
			} else {
				currentChar = ' ';
			}
			count.set(charToIndex(currentChar), count.get(charToIndex(currentChar)) + 1);

		}
		// -----------------------------------------------------------------------------------

		// Update count to store the position of the next occurrence of each character
		for (int i = 1; i < charSetSize; i++) {
			count.set(i, count.get(i) + count.get(i - 1));
		}
		// ----------------------------------------------------------------------------

		// Build the output list by placing strings in their sorted order
		for (int i = numOfItems - 1; i >= 0; i--) {

			char currentChar;

			if (position < sortFile.get(i).length()) {

				currentChar = sortFile.get(i).charAt(position);

			} else {

				currentChar = ' ';

			}

			int index = charToIndex(currentChar);
			output.set(count.get(index) - 1, sortFile.get(i));
			count.set(index, count.get(index) - 1);

		}
		// ----------------------------------------------------------------

		return output;
	}

	// Assigns each letter of the alpabet or space to a character 0-26----------
	public static int charToIndex(char c) {

		if (c == ' ') {

			return 0; // Map space to 0

		} else {

			return c - 'a' + 1; // Map 'a' to 1, 'b' to 2, ..., 'z' to 26

		}

	}
	// --------------------------------------------------------------------------

}
